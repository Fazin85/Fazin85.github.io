function GetName()
    return "Dirt"
end

function GetTextureName()
    return "Dirt"
end

function Tick(x, y, dimensionId)
    
end

function GetScale()
    return 1
end

function GetDrawColorR()
    return 255
end

function GetDrawColorG()
    return 255
end

function  GetDrawColorB()
    return 255
end

function GetDrawColorAlpha()
    return 255
end

function Tickable()
    return false
end

function Collidable()
    return true
end
