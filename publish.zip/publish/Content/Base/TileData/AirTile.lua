function GetName()
    return "Air"
end

function Tick(x, y, dimensionId)
    
end

function GetScale()
    return 1
end

function GetDrawColorR()
    return 0
end

function GetDrawColorG()
    return 0
end

function  GetDrawColorB()
    return 0
end

function GetDrawColorAlpha()
    return 0
end

function Tickable()
    return false
end

function Collidable()
    return false
end
