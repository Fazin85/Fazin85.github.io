function GetModName()
    return "Base"
end

function GetVersion()
    return "1.0"
end

function Init()
    
end