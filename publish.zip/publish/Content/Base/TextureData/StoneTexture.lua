function GetName()
    return "Stone"
end

function GetPath()
    return "Stone.png"
end