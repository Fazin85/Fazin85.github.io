function GetName()
    return "Sand"
end

function GetPath()
    return "Sand.png"
end