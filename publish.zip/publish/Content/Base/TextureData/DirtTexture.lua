function GetName()
    return "Dirt"
end

function GetPath()
    return "Dirt.png"
end