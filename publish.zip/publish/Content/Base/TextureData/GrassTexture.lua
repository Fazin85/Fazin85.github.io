function GetName()
    return "Grass"
end

function GetPath()
    return "Grass.png"
end